package com.cgi.bakery.BakeryProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BakeryProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BakeryProjectApplication.class, args);
	}
}
