package com.cgi.travel.models;

import java.io.Serializable;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.cgi.travel.controllers.ServiceOperator;


@Entity
@Table(name="ING_Flight")


public class Flight implements Serializable,Cloneable{

	@Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "FLT_SEQ")
	@SequenceGenerator(sequenceName = "flight_seq", allocationSize = 1, name = "FLT_SEQ")
	@Column(name="Flight_Code")
	private Long flightCode;
	@Column(name="Service_Operator",nullable=false,length=50)
	private ServiceOperator serviceOperator;
	@Column(name="From_City",nullable=false,length=50)
	private String fromCity;
	@Column(name="To_City",nullable=false,length=50)
	private String toCity;
	
	
	
	public Long getFlightCode() {
		return flightCode;
	}
	public void setFlightCode(Long flightCode) {
		this.flightCode = flightCode;
	}
	public ServiceOperator getServiceOperator() {
		return serviceOperator;
	}
	public void setServiceOperator(ServiceOperator serviceOperator) {
		this.serviceOperator = serviceOperator;
	}
	public String getFromCity() {
		return fromCity;
	}
	public void setFromCity(String fromCity) {
		this.fromCity = fromCity;
	}
	public String getToCity() {
		return toCity;
	}
	public void setToCity(String toCity) {
		this.toCity = toCity;
	}
	@Override
	public Flight clone() throws CloneNotSupportedException {
		return (Flight) super.clone();
	}
	/*
	public boolean isPersisted() {
		return flightCode>0;
	}
*/
}
