package com.cgi.springcoreutil.app;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cgi.springcoreutil.models.Customer;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Resource resource=new ClassPathResource("spring.xml");
        BeanFactory fact=new XmlBeanFactory(resource); 
        Customer customer=(Customer) fact.getBean("customer");
		if(customer instanceof Customer)
			System.out.println("Yes");

	}

}
