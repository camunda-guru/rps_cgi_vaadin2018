package com.cgi.travel.CGISpringBootTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgiSpringBootTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgiSpringBootTestApplication.class, args);
	}
}
