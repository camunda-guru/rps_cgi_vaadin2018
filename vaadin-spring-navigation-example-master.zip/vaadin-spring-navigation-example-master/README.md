# Vaadin Spring Navigation example

A reall simple example projet the uses Navigator with Vaadin Spring and most essentially shows how Vaadin Spring 1.1 simplifies the setup that most Vaadin Spring apps need to do. See the relevant change from the commit history.

Note that if you are wondering how to setup a more complex navigation for your app, refer to e.g. sidebar sample in [vaadin4spring examples](https://github.com/peholmst/vaadin4spring/tree/master/samples).
